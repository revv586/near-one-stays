# NEAR ONE · ที่พักใกล้ One Bangkok

เว็บไซต์ภาษาไทยสำหรับเปรียบเทียบที่พักในงบ 10,000 บาท โดยเน้นสัญญา 1–4 เดือนและ MRT ภายใน 3 สถานีจากลุมพินี

- เว็บไซต์หลัก: https://revv586.github.io/near-one-stays/
- Repository สาธารณะตามคำอนุญาต: https://github.com/revv586/near-one-stays
- GitHub Pages ใช้ GitHub Actions และ variable `NEARONE_PAGES_ENABLED=true`
- CI/CD ตรวจข้อมูล ทดสอบ และ deploy นาทีที่ 17 ของทุกชั่วโมง พร้อมรองรับ push และ workflow_dispatch; GitHub อาจเลื่อนเวลารันตามคิว
- เว็บส่วนตัวบน Sites เป็น snapshot แยก ไม่ได้อัปเดตตาม GitHub Pages โดยอัตโนมัติ

## ข้อมูลรอบ 6 พฤศจิกายน 2569

ตรวจหน้าที่พักตรงของ ZmyHome 101 หน้า เพิ่มเบาะแสใหม่ 40 แห่ง รวมหลักฐานกับอาคารเดิม 24 แห่ง รวมแค็ตตาล็อก 96 ที่พัก (รวมเบาะแส ห้องเต็ม และรายการไม่ผ่านเกณฑ์ ไม่ใช่ห้องที่ผ่านทุกเงื่อนไข 96 แห่ง)

มีหลักฐานจาก RentHub, Hongpak, ThaiApartment, LivingInsider, ZmyHome และประกาศปิดของ Kaidee; หน้าแหล่งค้นหาแสดงจำนวนที่นำเข้าจริงของแต่ละแหล่ง พร้อมเหตุผลคัดออกจาก DDproperty, Hipflat, Dot Property, ENNXO และ CondoThai ที่เปิดตรวจแล้ว

รายการใหม่ที่ไม่ระบุขั้นต่ำสัญญามี `offers: []` และแยกเป็นเบาะแส ไม่ใช้ราคารายปีหรือราคาอ้างอิงเป็นราคาเช่าสั้น ระยะที่เว็บแสดงแยกจากระยะเดินจริง; ยังไม่มีเส้นทางเดินที่ยืนยันและไม่มีการติดต่อเจ้าของ วันที่ผู้ลงประกาศไม่ระบุเก็บเป็น null ไม่ใช้วันตรวจเว็บแทน

## เปิดบน Mac

แตก ZIP แล้วดับเบิลคลิก `Install-on-Desktop.command` เพื่อสร้างโฟลเดอร์บน Desktop จากนั้นเปิด `Start.command` หรือรัน `npm start` และเปิด http://localhost:4173 ต้องมี Node.js 20+ และ Python 3.10+ ไม่มี dependencies เพิ่มเติม

ตัวกรองงบและการเรียงราคาใช้ราคาเช่าตามสัญญาก่อน หากยังไม่มี ใช้ `indicativePrice` ที่เป็นตัวเลขบวก โดยไม่เปลี่ยนเป็นราคาเช่าสั้น; รายการไม่มีราคาอยู่ท้ายการเรียง และตัวเลือกเฉพาะราคาเช่าสั้นยังกรองตาม `offers` เช่นเดิม

หลังแก้ JavaScript ให้รัน `npm run build` เพื่อสร้างชื่อไฟล์ตามเนื้อหา ป้องกันเบราว์เซอร์โหลดตัวกรองเวอร์ชันเก่าจากแคช

## ตรวจสอบและอัปเดต

```sh
npm test
npm run build
npm run refresh
```

- `dist/data/listings.json`: ข้อมูลหลักและสถานะตรวจต้นทาง
- `dist/data/import-report.json`: รายงานนำเข้าและลิงก์ประกาศตรง
- `dist/data/sources.json`: 18 แหล่งค้นหาพร้อมขอบเขตจริง
- `scripts/discovery-sources.json`: หน้ารวม RentHub/Hongpak 21 หน้า และ ZmyHome 3 หน้า
- `scripts/refresh.py`: ตรวจแหล่งต้นทางและค้นเบาะแส โดยเคารพ robots.txt ไม่ข้าม login หรือ CAPTCHA
- RentHub อ่านราคาเฉพาะช่องสัญญาระยะสั้นที่ระบุชัด; แหล่งอื่นตรวจการเปลี่ยนแปลงและตั้ง needsReview โดยไม่แก้ราคา/ห้องว่างด้วยการคาดเดา
- ZmyHome อ่านข้อมูลรายอาคารและราคาที่ยังไม่ทราบสัญญาแยกกัน หาก robots.txt หรือหน้าต้นทางอ่านไม่ได้ จะเก็บข้อมูลเดิมและแสดง error ไม่อ้างว่าตรวจสดสำเร็จ
- ผลค้นพบจากหน้ารวมเข้าคิวตรวจทาน ไม่กลายเป็นห้องผ่านเกณฑ์โดยอัตโนมัติ ต้องตรวจที่ตั้ง เพศ ห้องน้ำ สัญญา และทางเดินก่อน
- HTTP error หรือแหล่งเข้าถึงไม่ได้ไม่ถือว่าห้องเต็ม และไม่มีการรับรองว่าดึงประกาศครบทุกแพลตฟอร์ม
- รายการโปรดและเปรียบเทียบเก็บใน browser localStorage

`Enable-hourly-updates.command` และ `Disable-hourly-updates.command` ใช้ตั้ง/ปิด LaunchAgent บน Mac สำหรับเว็บ local เท่านั้น ไม่มีการอัปโหลดขึ้นเว็บออนไลน์

## การนำชุดอัปเดตขึ้น GitHub

Workflow รองรับ `near-one-source.zip` ที่ root เพื่อแตกไฟล์ก่อนตรวจและ commit source/data แล้วนำ ZIP ออกจาก repository ระหว่างรัน ไม่บรรจุ credentials หรือ Git metadata ลง ZIP และไม่เขียนทับ workflow ผ่าน payload นี้

## Facebook group posts

Reviewed public posts from groups `691988518250398` and `1116528203018291` are stored in `dist/data/facebook-posts.json`. The Facebook page links to actual imported records and their original posts; it includes reasons for exclusions and future availability. The price slider includes indicative prices without treating annual prices as short-lease offers.

`facebook_import.py` merges this curated input before each scheduled refresh, preserves unrelated current records, and is idempotent. Facebook records are excluded from the unattended HTTP checker. No passwords, cookies, session exports, or signed CDN image URLs are stored in this project. Local photo copies are credited to the original public post.

Facebook collection runs in a separate hourly browser task (minute 05, Asia/Bangkok). It reads only the two authorized public groups, records actual collection results, then submits the Facebook JSON for GitHub Actions to merge, test, and deploy. The ordinary HTTP checker still skips Facebook. Scheduled collection and deployment have been verified end to end; saving a schedule alone is not proof of a completed sync. Sessions and source availability can interrupt later runs.

The Facebook page shows each group's last successful read, the latest attempt, posts read/added/changed, and a warning after either group is more than 90 minutes old. Collection timestamps do not replace a property's last review, poster date, or owner confirmation. Coverage is limited to the posts actually loaded, not the entire group. See [the sync runbook](docs/facebook-sync-runbook.md) for the data-only fallback and verification steps.
